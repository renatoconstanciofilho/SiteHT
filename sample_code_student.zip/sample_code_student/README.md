# Hackatruck Bluemix Sample

Example of a CRUD server based on IBM Cloudant running on NodeJS

